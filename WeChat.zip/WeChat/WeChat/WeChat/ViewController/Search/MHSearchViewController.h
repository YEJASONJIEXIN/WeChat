//
//  MHSearchViewController.h
//  WeChat
//
//  Created by admin on 2020/5/6.
//  Copyright © 2020 CoderMikeHe. All rights reserved.
//  主要用于 微信 + 通讯录 搜索模块

//  这个作为 搜索类型 

#import "MHTableViewController.h"
#import "MHSearchViewModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface MHSearchViewController : MHTableViewController

@end

NS_ASSUME_NONNULL_END
