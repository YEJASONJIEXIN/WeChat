//
//  MHCommonViewController.h
//  WeChat
//
//  Created by senba on 2017/9/14.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  用于快速搭建 类似 设置界面的样式

#import "MHTableViewController.h"
#import "MHCommonViewModel.h"
@interface MHCommonViewController : MHTableViewController

@end
