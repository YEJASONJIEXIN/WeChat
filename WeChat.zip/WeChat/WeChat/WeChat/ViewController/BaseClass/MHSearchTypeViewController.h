//
//  MHSearchTypeViewController.h
//  WeChat
//
//  Created by admin on 2020/5/11.
//  Copyright © 2020 CoderMikeHe. All rights reserved.
//  搜索类型<盆友圈、文章、公众号、小程序、音乐、表情>搜索的 基类控制器

#import "MHTableViewController.h"
#import "MHSearchTypeViewModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface MHSearchTypeViewController : MHTableViewController

@end

NS_ASSUME_NONNULL_END
