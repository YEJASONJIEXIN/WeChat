//
//  MHHomePageViewController.h
//  WeChat
//
//  Created by senba on 2017/9/11.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  主界面控制器

#import "MHTabBarController.h"
#import "MHHomePageViewModel.h"

@interface MHHomePageViewController : MHTabBarController

@end
