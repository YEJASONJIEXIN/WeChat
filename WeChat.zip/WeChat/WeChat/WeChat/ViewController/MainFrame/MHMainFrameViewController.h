//
//  MHMainFrameViewController.h
//  WeChat
//
//  Created by senba on 2017/9/11.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  `微信`会话层页面

#import "MHTableViewController.h"
#import "MHMainFrameViewModel.h"
@interface MHMainFrameViewController : MHTableViewController

@end
