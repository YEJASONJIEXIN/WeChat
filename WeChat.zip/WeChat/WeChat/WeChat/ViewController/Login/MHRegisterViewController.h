//
//  MHRegisterViewController.h
//  WeChat
//
//  Created by senba on 2017/10/12.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  注册账号

#import "MHLoginBaseViewController.h"
#import "MHRegisterViewModel.h"
@interface MHRegisterViewController : MHLoginBaseViewController

@end
