//
//  MHBootLoginViewController.h
//  WeChat
//
//  Created by senba on 2017/9/26.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  `首次`使用微信的选择登录Or注册界面

#import "MHViewController.h"
#import "MHBootLoginViewModel.h"
@interface MHBootLoginViewController : MHViewController

@end
