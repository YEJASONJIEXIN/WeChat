//
//  MHCommitViewController.h
//  WeChat
//
//  Created by senba on 2017/10/12.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  提交手机号注册

#import "MHLoginBaseViewController.h"
#import "MHCommitViewModel.h"
@interface MHCommitViewController : MHLoginBaseViewController

@end
