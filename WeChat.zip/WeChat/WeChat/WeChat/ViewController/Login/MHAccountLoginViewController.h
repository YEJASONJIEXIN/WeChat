//
//  MHAccountLoginViewController.h
//  WeChat
//
//  Created by senba on 2017/9/11.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  账户登录主页面 （PS: 当你成功登录后，退出登录后的登录界面）

/// CoderMikeHe TODO
/// 2. 手机号格式化 （+86 138 7438 5438）

#import "MHLoginBaseViewController.h"
#import "MHAccountLoginViewModel.h"
@interface MHAccountLoginViewController : MHLoginBaseViewController

@end
