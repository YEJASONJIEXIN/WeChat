//
//  MHNewFeatureViewController.h
//  WeChat
//
//  Created by senba on 2017/9/11.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  `新特性`模块

#import "MHViewController.h"
#import "MHNewFeatureViewModel.h"
@interface MHNewFeatureViewController : MHViewController

@end
