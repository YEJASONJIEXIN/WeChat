//
//  MHContactsViewController.h
//  WeChat
//
//  Created by senba on 2017/9/11.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  通讯录模块

#import "MHTableViewController.h"
#import "MHContactsViewModel.h"
@interface MHContactsViewController : MHTableViewController

@end
