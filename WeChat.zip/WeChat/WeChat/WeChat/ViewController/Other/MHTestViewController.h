//
//  MHTestViewController.h
//  WeChat
//
//  Created by senba on 2017/10/20.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHViewController.h"
#import "MHTestViewModel.h"

@interface MHTestViewController : MHViewController

@end
