//
//  MHImageView.h
//  WeChat
//
//  Created by senba on 2017/10/19.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  允许用户接受事件的 UIImageView

#import <UIKit/UIKit.h>

@interface MHImageView : UIImageView

@end
