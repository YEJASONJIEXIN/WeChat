//
//  MHScrollView.m
//  WeChat
//
//  Created by 何千元 on 2020/7/8.
//  Copyright © 2020 CoderMikeHe. All rights reserved.
//

#import "MHScrollView.h"

@implementation MHScrollView

/**
 同时识别多个手势

 @param gestureRecognizer gestureRecognizer description
 @param otherGestureRecognizer otherGestureRecognizer description
 @return return value description
 */
//- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
//{
//    MHLogFunc;
//    return NO;
//}


@end
