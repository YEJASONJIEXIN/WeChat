//
//  MHNavSearchBar.h
//  WeChat
//
//  Created by 何千元 on 2020/5/3.
//  Copyright © 2020 CoderMikeHe. All rights reserved.
//  用于和导航栏做动画 搜索栏  微信首页、通讯录

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MHNavSearchBar : UIView<MHReactiveView>

@end

NS_ASSUME_NONNULL_END
