//
//  MHSearchVoiceInputView.h
//  WeChat
//
//  Created by admin on 2020/5/8.
//  Copyright © 2020 CoderMikeHe. All rights reserved.
//  语音输入

#import "MHView.h"

NS_ASSUME_NONNULL_BEGIN

@interface MHSearchVoiceInputView : MHView

/// 构造方法
+ (instancetype)voiceInputView;

@end

NS_ASSUME_NONNULL_END
