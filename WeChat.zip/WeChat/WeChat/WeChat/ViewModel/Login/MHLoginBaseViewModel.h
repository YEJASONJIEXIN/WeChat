//
//  MHLoginBaseViewModel.h
//  WeChat
//
//  Created by senba on 2017/9/26.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHViewModel.h"

@interface MHLoginBaseViewModel : MHViewModel

@end
