//
//  MHNewFeatureViewModel.m
//  WeChat
//
//  Created by senba on 2017/9/11.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHNewFeatureViewModel.h"

@implementation MHNewFeatureViewModel
- (void)initialize{
    [super initialize];
    
    /// 隐藏导航栏
    self.prefersNavigationBarHidden = YES;
    
}
@end
