//
//  MHDiscoverViewModel.h
//  WeChat
//
//  Created by senba on 2017/9/11.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHCommonViewModel.h"
#import "MHCommonArrowItemViewModel.h"
@interface MHDiscoverViewModel : MHCommonViewModel

@end
