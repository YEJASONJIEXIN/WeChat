//
//  MHAppletViewModel.h
//  WeChat
//
//  Created by admin on 2020/7/1.
//  Copyright © 2020 CoderMikeHe. All rights reserved.
//

#import "MHTableViewModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MHAppletViewModel : MHTableViewModel

@end

NS_ASSUME_NONNULL_END
