//
//  MHAppletViewModel.m
//  WeChat
//
//  Created by admin on 2020/7/1.
//  Copyright © 2020 CoderMikeHe. All rights reserved.
//

#import "MHAppletViewModel.h"

@implementation MHAppletViewModel
- (void)initialize {
    [super initialize];
    
    self.title = @"小程序";
}
@end
