//
//  MHTestViewModel.m
//  WeChat
//
//  Created by senba on 2017/10/20.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHTestViewModel.h"

@implementation MHTestViewModel

@end
