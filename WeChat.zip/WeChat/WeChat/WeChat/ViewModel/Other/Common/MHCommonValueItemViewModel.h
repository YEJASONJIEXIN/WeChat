//
//  MHCommonValueItemViewModel.h
//  WeChat
//
//  Created by senba on 2017/12/11.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHCommonItemViewModel.h"

@interface MHCommonValueItemViewModel : MHCommonItemViewModel
/// 存储数据用的key
@property (nonatomic, readwrite, copy) NSString *key;
@end
