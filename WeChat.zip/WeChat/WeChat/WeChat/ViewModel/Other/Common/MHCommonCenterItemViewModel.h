//
//  MHCommonCenterItemViewModel.h
//  WeChat
//
//  Created by admin on 2020/6/5.
//  Copyright © 2020 CoderMikeHe. All rights reserved.
//  显示在中间的  例如 退出登录

#import "MHCommonItemViewModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MHCommonCenterItemViewModel : MHCommonItemViewModel

@end

NS_ASSUME_NONNULL_END
