//
//  MHCommonArrowItemViewModel.m
//  WeChat
//
//  Created by senba on 2017/9/14.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  带箭头的  （icon + title + subTitle + arrow）

#import "MHCommonArrowItemViewModel.h"

@implementation MHCommonArrowItemViewModel

@end
