//
//  MHCommonQRCodeItemViewModel.m
//  WeChat
//
//  Created by senba on 2017/9/21.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHCommonQRCodeItemViewModel.h"

@implementation MHCommonQRCodeItemViewModel

@end
