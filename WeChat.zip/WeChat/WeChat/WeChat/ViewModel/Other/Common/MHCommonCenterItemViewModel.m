//
//  MHCommonCenterItemViewModel.m
//  WeChat
//
//  Created by admin on 2020/6/5.
//  Copyright © 2020 CoderMikeHe. All rights reserved.
//

#import "MHCommonCenterItemViewModel.h"

@implementation MHCommonCenterItemViewModel

@end
