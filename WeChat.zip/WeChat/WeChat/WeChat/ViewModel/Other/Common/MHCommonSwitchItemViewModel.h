//
//  MHCommonSwitchItemViewModel.h
//  WeChat
//
//  Created by senba on 2017/12/11.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHCommonValueItemViewModel.h"

@interface MHCommonSwitchItemViewModel : MHCommonValueItemViewModel
/// 开关状态
@property (nonatomic, readwrite, assign) BOOL off;
@end
