//
//  MHTestViewModel.h
//  WeChat
//
//  Created by senba on 2017/10/20.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHViewModel.h"

@interface MHTestViewModel : MHViewModel

@end
