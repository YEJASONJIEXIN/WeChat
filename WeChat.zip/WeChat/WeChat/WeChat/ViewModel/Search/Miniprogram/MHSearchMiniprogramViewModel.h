//
//  MHSearchMiniprogramViewModel.h
//  WeChat
//
//  Created by 何千元 on 2020/5/13.
//  Copyright © 2020 CoderMikeHe. All rights reserved.
//  小程序模块 只有搜索模式 没有关联模式

#import "MHSearchTypeViewModel.h"
#import "MHSearchCommonSearchItemViewModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface MHSearchMiniprogramViewModel : MHSearchTypeViewModel

@end

NS_ASSUME_NONNULL_END
