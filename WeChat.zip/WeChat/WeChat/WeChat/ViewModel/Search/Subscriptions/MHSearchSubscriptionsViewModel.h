//
//  MHSearchSubscriptionsViewModel.h
//  WeChat
//
//  Created by 何千元 on 2020/5/13.
//  Copyright © 2020 CoderMikeHe. All rights reserved.
//  搜索文章模块  关联模式 + 搜索模式

#import "MHSearchTypeViewModel.h"
#import "MHSearchCommonSearchItemViewModel.h"
#import "MHSearchCommonRelatedItemViewModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface MHSearchSubscriptionsViewModel : MHSearchTypeViewModel

@end

NS_ASSUME_NONNULL_END
