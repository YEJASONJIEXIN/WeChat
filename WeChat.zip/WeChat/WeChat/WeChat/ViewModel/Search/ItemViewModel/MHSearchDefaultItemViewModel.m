//
//  MHSearchDefaultItemViewModel.m
//  WeChat
//
//  Created by admin on 2020/5/20.
//  Copyright © 2020 CoderMikeHe. All rights reserved.
//

#import "MHSearchDefaultItemViewModel.h"

@implementation MHSearchDefaultItemViewModel
- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

- (CGFloat)cellHeight {
    return 44.0f;
}
@end
