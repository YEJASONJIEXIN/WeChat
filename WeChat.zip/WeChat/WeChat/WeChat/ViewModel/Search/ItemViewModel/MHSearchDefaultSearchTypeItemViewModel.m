//
//  MHSearchDefaultSearchTypeItemViewModel.m
//  WeChat
//
//  Created by admin on 2020/5/7.
//  Copyright © 2020 CoderMikeHe. All rights reserved.
//

#import "MHSearchDefaultSearchTypeItemViewModel.h"

@interface MHSearchDefaultSearchTypeItemViewModel ()


@end



@implementation MHSearchDefaultSearchTypeItemViewModel

- (instancetype)init
{
    self = [super init];
    if (self) {
    
    }
    return self;
}

- (CGFloat)cellHeight {
    return 171.0f;
}

@end
