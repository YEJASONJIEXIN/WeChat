//
//  MHSearchMusicViewModel.h
//  WeChat
//
//  Created by 何千元 on 2020/5/13.
//  Copyright © 2020 CoderMikeHe. All rights reserved.
//

#import "MHSearchTypeViewModel.h"
#import "MHSearchMusicHotItemViewModel.h"
#import "MHSearchMusicHistoryItemViewModel.h"
#import "MHSearchMusicDelHistoryItemViewModel.h"
#import "MHSearchCommonSearchItemViewModel.h"
#import "MHSearchCommonRelatedItemViewModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface MHSearchMusicViewModel : MHSearchTypeViewModel

@end

NS_ASSUME_NONNULL_END
