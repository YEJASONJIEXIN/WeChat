//
//  MHSearchOfficialAccountsViewModel.h
//  WeChat
//
//  Created by admin on 2020/5/8.
//  Copyright © 2020 CoderMikeHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MHSearchTypeViewModel.h"
#import "MHSearchCommonSearchItemViewModel.h"
#import "MHSearchCommonRelatedItemViewModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface MHSearchOfficialAccountsViewModel : MHSearchTypeViewModel

@end

NS_ASSUME_NONNULL_END
