//
//  MHPulldownAppletViewModel.h
//  WeChat
//
//  Created by admin on 2020/6/28.
//  Copyright © 2020 CoderMikeHe. All rights reserved.
//

#import "MHTableViewModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MHPulldownAppletViewModel : MHTableViewModel

@end

NS_ASSUME_NONNULL_END
