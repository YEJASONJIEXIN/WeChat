//
//  MHDiscoverManagerViewModel.h
//  WeChat
//
//  Created by 何千元 on 2020/6/6.
//  Copyright © 2020 CoderMikeHe. All rights reserved.
//

#import "MHCommonViewModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MHDiscoverManagerViewModel : MHCommonViewModel

@end

NS_ASSUME_NONNULL_END
