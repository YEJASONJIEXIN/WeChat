//
//  MHMoreEmotionViewModel.h
//  WeChat
//
//  Created by senba on 2017/12/20.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHTableViewModel.h"

@interface MHMoreEmotionViewModel : MHTableViewModel

@end
