//
//  MHCommonViewModel.h
//  WeChat
//
//  Created by senba on 2017/9/14.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHTableViewModel.h"
#import "MHCommonItemViewModel.h"
#import "MHCommonGroupViewModel.h"
@interface MHCommonViewModel : MHTableViewModel





@end
