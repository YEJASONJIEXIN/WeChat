//
//  MHViewModelServicesImpl.h
//  WeChat
//
//  Created by senba on 2017/9/10.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  视图模型服务层的实现

#import <Foundation/Foundation.h>
#import "MHViewModelServices.h"
@interface MHViewModelServicesImpl : NSObject<MHViewModelServices>
@end
