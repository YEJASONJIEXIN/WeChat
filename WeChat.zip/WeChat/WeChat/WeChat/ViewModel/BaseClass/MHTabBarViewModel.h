//
//  MHTabBarViewModel.h
//  WeChat
//
//  Created by senba on 2017/9/10.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  对应于`MHTabBarViewController`的视图模型 ,只是一个用来过渡的视图模型

#import "MHViewModel.h"

@interface MHTabBarViewModel : MHViewModel

@end
