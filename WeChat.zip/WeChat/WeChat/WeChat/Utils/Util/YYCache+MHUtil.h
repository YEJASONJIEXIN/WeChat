//
//  YYCache+MHUtil.h
//  WeChat
//
//  Created by admin on 2020/5/14.
//  Copyright © 2020 CoderMikeHe. All rights reserved.
//

#import <YYCache/YYCache.h>

/// 搜索-搜索音乐
FOUNDATION_EXTERN NSString * _Nullable const MHSearchMusicHistoryCacheKey;

NS_ASSUME_NONNULL_BEGIN

@interface YYCache (MHUtil)
// 单例
+ (instancetype)sharedCache;
@end

NS_ASSUME_NONNULL_END
