//
//  MHEmoticon.m
//  WeChat
//
//  Created by senba on 2018/1/20.
//  Copyright © 2018年 CoderMikeHe. All rights reserved.
//  单个表情

#import "MHEmoticon.h"



@implementation MHEmoticon
+ (NSArray *)modelPropertyBlacklist {
    return @[@"group"];
}
@end
