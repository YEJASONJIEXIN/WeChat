//
//  MHURLConfigure.h
//  WeChat
//
//  Created by senba on 2017/10/19.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#ifndef MHURLConfigure_h
#define MHURLConfigure_h

/// 获取直播间列表
#define MH_GET_LIVE_ROOM_LIST  @"Room/GetHotLive_v2"

#endif /* MHURLConfigure_h */
